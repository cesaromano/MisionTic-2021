//EL CALIFICADOR GENERARÁ ERROR SI USTED NO IMPLEMENTA TODOS LOS MÉTODOS ESPECIFICADOS EN EL ENUNCIADO
public abstract class Asiento {

    //Inserte acá los atributos

    //Inserte acá el método constructor

    //Inserte acá los SETTERS Y GETTERS

    //Inserte acá los métodos (NO LOS GETTER Y SETTERS)

}